<?php

return array(
	'Model Name'=>'Nom du modèle',
	'Lable field name'=>'Nom du champ Lable',
	'Empty item name'=>'Vider nom de l\'article',
	'Profile model relation name'=>'Nom du profil modèle des relations',
);
